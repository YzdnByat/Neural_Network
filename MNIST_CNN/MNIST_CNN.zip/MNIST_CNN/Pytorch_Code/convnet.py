import torch.nn as nn
import torch

n_class = 10

class convnet(nn.Module):
    def __init__(self):
        super(convnet, self).__init__()

        # Step 1: Define convolutional layers first
        self.layer1 = nn.Sequential(
            nn.Conv2d(1, 16, kernel_size=3, stride=1, padding=2),
            nn.BatchNorm2d(16),
            nn.ReLU(),
            nn.MaxPool2d(2, 2)
        )
        self.layer2 = nn.Sequential(
            nn.Conv2d(16, 32, kernel_size=3, stride=1, padding=2),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d(2, 2)
        )

        # Step 2: Use those layers to compute flattened size
        with torch.no_grad():
            dummy = torch.zeros(1, 1, 28, 28)
            dummy = self.layer1(dummy)
            dummy = self.layer2(dummy)
            self.flattened_size = dummy.view(1, -1).shape[1]
        print("Flattened size:", self.flattened_size)

        # Step 3: Define FC layer with correct input size
        self.fc = nn.Linear(self.flattened_size, n_class)

    def forward(self, x):
        x = self.layer1(x)
        x = self.layer2(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        return x

