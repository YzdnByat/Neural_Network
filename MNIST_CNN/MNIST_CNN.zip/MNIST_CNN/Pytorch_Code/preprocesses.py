import torch
import torchvision
from torchvision import transforms
from load_data import *
import matplotlib.pyplot as plt
from collections import Counter
from torch.utils.data import random_split


# train_loader = torch.utils.data.DataLoader(dataset=train_dataset,
#                                            batch_size=batch_size,
#                                            shuffle=True)
# test_loader = torch.utils.data.DataLoader(dataset=test_dataset,
#                                           batch_size=batch_size,
#                                           shuffle=False)

# Preprocesses
train_len = int(len(train_dataset) * 0.9)
val_len = len(train_dataset) - train_len

train_dataset, valid_dataset = random_split(
    train_dataset,
    [train_len, val_len],
    generator=torch.Generator().manual_seed(42)  # You can change the seed
)
train_loader = torch.utils.data.DataLoader(dataset=train_dataset,
                                           batch_size=batch_size,
                                           shuffle=True)
test_loader = torch.utils.data.DataLoader(dataset=test_dataset,
                                          batch_size=batch_size,
                                          shuffle=False)
valid_loader = torch.utils.data.DataLoader(dataset=valid_dataset,
                                           batch_size=batch_size,
                                           shuffle=False)

print(f"number of train samples: {len(train_dataset)}")
print(f"number of test samples: {len(test_dataset)}")

img, label = train_dataset[0]
print(f"img: {img.shape}")
print(f"label: {label}")

# Show a few images
def show_images(dataset, n=6):
    plt.figure(figsize=(12, 2))
    for i in range(n):
        image, lbls = dataset[i]
        plt.subplot(1, n, i+1)
        plt.imshow(image.squeeze(), cmap='gray')
        plt.title(f"Label: {lbls}")
        plt.axis('off')
    plt.show()

show_images(train_dataset)

labels = [label for _, label in train_dataset]
counter = Counter(labels)

# Plot the label distribution
plt.bar(counter.keys(), counter.values())
plt.xlabel('Digit Label')
plt.ylabel('Count')
plt.title('Distribution of Digits in Training Set')
plt.show()
