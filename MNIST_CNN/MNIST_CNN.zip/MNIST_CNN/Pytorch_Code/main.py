import torch
import torchvision
from networkx.algorithms.clique import enumerate_all_cliques
from torchvision import transforms
from load_data import *
import matplotlib.pyplot as plt
from collections import Counter
import torch.nn as nn
from convnet import *
from preprocesses import *

# Device configuration
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")


# Params
batch_size = 256
n_class = 10
lr = 0.001
num_epochs = 5


# # Model CNN
# conv_model = convnet()
#
# # Loss
# loss_fn = nn.CrossEntropyLoss()
#
# # Optimizer
# optimizer = torch.optim.Adam(conv_model.parameters(), lr=lr)
#
# #train
# conv_model = convnet().to(device)  # move model to GPU
# num_steps = len(train_loader)
#
# for i in range(num_epochs):
#     conv_model.train()  # make sure model is in training mode each epoch
#     for j, (imgs, lbls) in enumerate(train_loader):
#         imgs = imgs.to(device)
#         lbls = lbls.to(device)
#         out = conv_model(imgs)
#         loss_val = loss_fn(out, lbls)
#         optimizer.zero_grad()
#         loss_val.backward()
#         optimizer.step()
#
#         if j % 50 == 0:
#             print('Epoch [{}/{}]  Step [{}/{}]  Loss [{:.4f}]'
#                   .format(i+1, num_epochs, j+1, num_steps, loss_val.item()))
#
#
#     conv_model.eval()
#     corrects = 0
#     num_steps = len(valid_loader)
#     for k, (imgs, lbls) in enumerate(valid_loader):
#         imgs = imgs.to(device)
#         lbls = lbls.to(device)
#         out = conv_model(imgs)
#         loss_val = loss_fn(out, lbls)
#         predicted = torch.argmax(out, 1)
#         corrects += (predicted == lbls).sum().item()
#         print('Validation, step: [{}/{}]  Loss [{:.4f}]  Accuracy [{:.4f}]'.
#               format(k+1, num_steps, loss_val.item(), corrects/num_steps))


# Initialize
model = convnet().to(device)
loss_fn = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=lr)

# Tracking losses
train_losses = []
valid_losses = []

# Training loop
num_steps = len(train_loader)
for epoch in range(num_epochs):
    model.train()
    running_loss = 0.0
    for j, (imgs, lbls) in enumerate(train_loader):
        imgs = imgs.to(device)
        lbls = lbls.to(device)
        out = model(imgs)
        loss = loss_fn(out, lbls)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        running_loss += loss.item()
        if j % 50 == 0:
          print('epoch: [{}/{}] | step: [{}/{}] | loss: {:.6f}'
          .format(epoch+1, num_epochs, j+1, num_steps, loss))
    train_losses.append(running_loss / len(train_loader))

    model.eval()
    valid_loss = 0.0
    correct = 0
    total = 0
    with torch.no_grad():
        for imgs, lbls in valid_loader:
            imgs = imgs.to(device)
            lbls = lbls.to(device)
            out = model(imgs)
            loss = loss_fn(out, lbls)
            valid_loss += loss.item()
            predicted = torch.argmax(out, 1)
            correct += (predicted == lbls).sum().item()
            total += lbls.size(0)
    valid_losses.append(valid_loss / len(valid_loader))
    print(f"Epoch [{epoch+1}/{num_epochs}] | Val Loss: {valid_loss/len(valid_loader):.4f} | Val Acc: {100. * correct / total:.2f}%")

# Plot losses
plt.plot(range(1, num_epochs+1), train_losses, label='Train Loss')
plt.plot(range(1, num_epochs+1), valid_losses, label='Validation Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.title('Training vs Validation Loss')
plt.legend()
plt.grid(True)
plt.show()




# Test
model.eval()
corrects = 0
total = 0

with torch.no_grad():
    for imgs, lbls in test_loader:
        imgs = imgs.to(device)
        lbls = lbls.to(device)
        out = model(imgs)
        predicted = torch.argmax(out, 1)
        corrects += (predicted == lbls).sum().item()
        total += lbls.size(0)

test_accuracy = 100. * corrects / total
print(f"\nTest Accuracy: {test_accuracy:.2f}%")